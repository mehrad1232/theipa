﻿#import <Foundation/Foundation.h>

@interface NOVAMonitor : NSObject
+ (NSString *)summary;
@end
