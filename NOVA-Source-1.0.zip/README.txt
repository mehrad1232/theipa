﻿NOVA iOS ULTIMATE SUITE
Version 0.1.0

Target:
iPhone 5s
iOS 12.5.8
ARM64
Amethyst jailbreak

Modules:
1. Control Center - prototype launcher/dashboard
2. Terminal - planned
3. System Monitor - basic memory/battery information
4. Lock Screen - planned
5. Settings - planned
6. Network Toolkit - basic reachability check

BUILD:
make package

IMPORTANT:
This is source code, not a compiled DEB.
Build with a compatible Theos environment.
Do not install until the package has been built and checked.
