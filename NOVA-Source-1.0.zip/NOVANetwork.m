﻿#import "NOVANetwork.h"
#import <SystemConfiguration/SystemConfiguration.h>

@implementation NOVANetwork

+ (NSString *)quickReport {
    SCNetworkReachabilityRef ref =
        SCNetworkReachabilityCreateWithName(NULL, "apple.com");

    SCNetworkReachabilityFlags flags = 0;

    BOOL success = ref &&
        SCNetworkReachabilityGetFlags(ref, &flags);

    if (ref) CFRelease(ref);

    BOOL reachable = success &&
        (flags & kSCNetworkReachabilityFlagsReachable);

    return reachable
        ? @"NOVA NETWORK\nInternet route: AVAILABLE"
        : @"NOVA NETWORK\nInternet route: UNAVAILABLE";
}

@end
