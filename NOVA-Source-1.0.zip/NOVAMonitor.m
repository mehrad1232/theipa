﻿#import "NOVAMonitor.h"
#import <UIKit/UIKit.h>
#import <mach/mach.h>

@implementation NOVAMonitor

+ (NSString *)summary {
    UIDevice.currentDevice.batteryMonitoringEnabled = YES;

    vm_statistics_data_t vm;
    mach_msg_type_number_t count = HOST_VM_INFO_COUNT;

    kern_return_t result = host_statistics(
        mach_host_self(),
        HOST_VM_INFO,
        (host_info_t)&vm,
        &count
    );

    NSString *memory = result == KERN_SUCCESS
        ? [NSString stringWithFormat:@"Free memory pages: %u", vm.free_count]
        : @"Memory unavailable";

    NSString *battery = [NSString stringWithFormat:
        @"Battery: %.0f%%",
        UIDevice.currentDevice.batteryLevel * 100.0
    ];

    return [NSString stringWithFormat:
        @"NOVA SYSTEM MONITOR\n%@\n%@\nDevice: %@",
        memory,
        battery,
        UIDevice.currentDevice.model
    ];
}

@end
