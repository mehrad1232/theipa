﻿#import <Foundation/Foundation.h>

@interface NOVANetwork : NSObject
+ (NSString *)quickReport;
@end
