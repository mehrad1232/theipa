#import <UIKit/UIKit.h>
#import "NOVAMonitor.h"
#import "NOVANetwork.h"

static void NOVAShowDashboard(void);

@interface NOVAButtonTarget : NSObject
+ (instancetype)shared;
- (void)open:(id)sender;
- (void)drag:(UIPanGestureRecognizer *)gesture;
@end

@interface NOVADashboard : UIViewController
@end

@implementation NOVAButtonTarget

+ (instancetype)shared {
    static NOVAButtonTarget *target;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        target = [NOVAButtonTarget new];
    });
    return target;
}

- (void)open:(id)sender {
    NOVAShowDashboard();
}

- (void)drag:(UIPanGestureRecognizer *)gesture {
    UIView *view = gesture.view;
    UIView *parent = view.superview;
    if (!parent) return;

    CGPoint delta = [gesture translationInView:parent];
    CGPoint center = view.center;
    center.x += delta.x;
    center.y += delta.y;

    CGFloat halfW = view.bounds.size.width / 2.0;
    CGFloat halfH = view.bounds.size.height / 2.0;

    center.x = MAX(halfW, MIN(parent.bounds.size.width - halfW, center.x));
    center.y = MAX(halfH, MIN(parent.bounds.size.height - halfH, center.y));

    view.center = center;
    [gesture setTranslation:CGPointZero inView:parent];
}

@end

@implementation NOVADashboard {
    UILabel *_status;
    UIScrollView *_scroll;
    UIView *_content;
    BOOL _menuExpanded;
}

- (UIColor *)backgroundColor {
    return [UIColor colorWithRed:0.025 green:0.035 blue:0.065 alpha:1];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [self backgroundColor];

    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *glass = [[UIVisualEffectView alloc] initWithEffect:blur];
    glass.frame = self.view.bounds;
    glass.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    glass.alpha = 0.20;
    [self.view addSubview:glass];

    _scroll = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    _scroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:_scroll];

    CGFloat width = self.view.bounds.size.width;
    _content = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, 900)];
    _content.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [_scroll addSubview:_content];
    _scroll.contentSize = _content.bounds.size;

    [self buildInterface];
}

- (void)addLabel:(NSString *)text
           frame:(CGRect)frame
            size:(CGFloat)size
           color:(UIColor *)color
          parent:(UIView *)parent {
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.text = text;
    label.textColor = color;
    label.font = [UIFont systemFontOfSize:size weight:UIFontWeightSemibold];
    label.numberOfLines = 0;
    [parent addSubview:label];
}

- (UIView *)cardAtY:(CGFloat)y height:(CGFloat)height {
    CGFloat width = self.view.bounds.size.width;
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(18, y, width - 36, height)];
    card.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    card.backgroundColor = [UIColor colorWithWhite:1 alpha:0.075];
    card.layer.cornerRadius = 19;
    card.layer.borderWidth = 1;
    card.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.10].CGColor;
    [_content addSubview:card];
    return card;
}

- (UIButton *)makeButton:(NSString *)title
                     tag:(NSInteger)tag
                      y:(CGFloat)y
                  parent:(UIView *)parent {
    CGFloat width = parent.bounds.size.width;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(12, y, width - 24, 47);
    button.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    button.backgroundColor = [UIColor colorWithRed:0.12 green:0.24 blue:0.43 alpha:0.85];
    button.layer.cornerRadius = 13;
    button.tag = tag;
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    [button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [parent addSubview:button];
    return button;
}

- (void)buildInterface {
    CGFloat width = self.view.bounds.size.width;

    [self addLabel:@"NOVA" frame:CGRectMake(23, 24, width - 46, 38)
              size:30 color:UIColor.whiteColor parent:_content];

    [self addLabel:@"ULTIMATE SYSTEM SUITE"
             frame:CGRectMake(24, 62, width - 48, 22)
              size:11 color:[UIColor colorWithRed:0.30 green:0.65 blue:1 alpha:1]
             parent:_content];

    UIView *statusCard = [self cardAtY:105 height:145];

    [self addLabel:@"SYSTEM OVERVIEW"
             frame:CGRectMake(16, 13, 250, 25)
              size:13 color:[UIColor colorWithWhite:1 alpha:0.65]
             parent:statusCard];

    _status = [[UILabel alloc] initWithFrame:CGRectMake(16, 43, statusCard.bounds.size.width - 32, 90)];
    _status.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _status.numberOfLines = 0;
    _status.textColor = UIColor.whiteColor;
    _status.font = ([UIFont fontWithName:@"Menlo-Regular" size:12] ?: [UIFont systemFontOfSize:12]);
    _status.text = [NOVAMonitor summary];
    [statusCard addSubview:_status];

    UIView *networkCard = [self cardAtY:265 height:92];
    [self addLabel:@"NETWORK STATUS"
             frame:CGRectMake(16, 12, 230, 22)
              size:13 color:[UIColor colorWithWhite:1 alpha:0.65]
             parent:networkCard];

    [self addLabel:[NOVANetwork quickReport]
             frame:CGRectMake(16, 39, networkCard.bounds.size.width - 32, 40)
              size:13 color:UIColor.whiteColor parent:networkCard];

    UIView *modules = [self cardAtY:372 height:440];
    [self addLabel:@"TOOLS & MODULES"
             frame:CGRectMake(16, 12, 250, 25)
              size:13 color:[UIColor colorWithWhite:1 alpha:0.65]
             parent:modules];

    NSArray *names = @[
        @"↻   Refresh System Monitor",
        @"⌁   Refresh Network Status",
        @"☰   Toggle Side Menu",
        @"⚙   NOVA Preferences",
        @"▣   Lock Screen Tools",
        @"⌘   Terminal Tools",
        @"×   Close Dashboard"
    ];

    for (NSInteger i = 0; i < names.count; i++) {
        [self makeButton:names[i] tag:i y:49 + i * 53 parent:modules];
    }

    [self addLabel:@"NOVA ULTIMATE  •  iOS 12"
             frame:CGRectMake(20, 830, width - 40, 25)
              size:11 color:[UIColor colorWithWhite:1 alpha:0.38]
             parent:_content];

    _content.frame = CGRectMake(0, 0, width, 870);
    _scroll.contentSize = CGSizeMake(width, 870);
}

- (void)buttonPressed:(UIButton *)button {
    switch (button.tag) {
        case 0:
            _status.text = [NOVAMonitor summary];
            break;
        case 1: {
            UIView *card = [_content.subviews objectAtIndex:3];
            for (UIView *view in card.subviews) {
                if ([view isKindOfClass:[UILabel class]]) {
                    UILabel *label = (UILabel *)view;
                    if (label.frame.origin.y > 30) {
                        label.text = [NOVANetwork quickReport];
                    }
                }
            }
            break;
        }
        case 2:
            _menuExpanded = !_menuExpanded;
            _status.text = _menuExpanded
                ? @"NOVA SIDE MENU\nMenu state: EXPANDED"
                : @"NOVA SIDE MENU\nMenu state: COLLAPSED";
            break;
        case 3:
            _status.text = @"NOVA PREFERENCES\nSettings module is not implemented yet.";
            break;
        case 4:
            _status.text = @"LOCK SCREEN TOOLS\nAdvanced lock screen controls are not implemented yet.";
            break;
        case 5:
            _status.text = @"TERMINAL TOOLS\nTerminal integration is not implemented yet.";
            break;
        case 6:
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
    }
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

@end

static void NOVAShowDashboard(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIApplication *app = [UIApplication sharedApplication];
        UIWindow *window = app.keyWindow;

        if (!window) {
            for (UIWindow *candidate in app.windows) {
                if (candidate.isKeyWindow) {
                    window = candidate;
                    break;
                }
            }
        }

        UIViewController *root = window.rootViewController;
        if (!root) return;

        UIViewController *presenter = root;
        while (presenter.presentedViewController &&
               !presenter.presentedViewController.isBeingDismissed) {
            presenter = presenter.presentedViewController;
        }

        if ([presenter isKindOfClass:[NOVADashboard class]]) return;

        NOVADashboard *dashboard = [NOVADashboard new];
        dashboard.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [presenter presentViewController:dashboard animated:YES completion:nil];
    });
}

%hook SpringBoard

- (void)applicationDidFinishLaunching:(id)application {
    %orig;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC),
                   dispatch_get_main_queue(), ^{
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        if (!window) return;

        for (UIView *view in window.subviews) {
            if (view.tag == 17002020) return;
        }

        UIButton *launcher = [UIButton buttonWithType:UIButtonTypeSystem];
        launcher.tag = 17002020;
        launcher.frame = CGRectMake(window.bounds.size.width - 65,
                                     window.bounds.size.height * 0.55,
                                     50, 50);
        launcher.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin |
                                    UIViewAutoresizingFlexibleTopMargin;
        launcher.backgroundColor = [UIColor colorWithRed:0.10 green:0.42 blue:0.95 alpha:1];
        launcher.layer.cornerRadius = 25;
        launcher.layer.borderWidth = 1;
        launcher.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.45].CGColor;

        [launcher setTitle:@"N" forState:UIControlStateNormal];
        [launcher setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        launcher.titleLabel.font = [UIFont boldSystemFontOfSize:24];

        [launcher addTarget:[NOVAButtonTarget shared]
                     action:@selector(open:)
           forControlEvents:UIControlEventTouchUpInside];

        UIPanGestureRecognizer *pan =
            [[UIPanGestureRecognizer alloc] initWithTarget:[NOVAButtonTarget shared]
                                                    action:@selector(drag:)];
        [launcher addGestureRecognizer:pan];
        [window addSubview:launcher];
    });
}

%end